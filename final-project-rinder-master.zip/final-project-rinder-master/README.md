# Rinder

URL: https://rtinder.herokuapp.com

Description: It's like Tinder but for restaurants! The project asks a user for location first. Using this information, we get a list of restaurants that best match the user using Yelp's API. The application will then suggest a restaurant to the user. The user can then "swipe" to the right to accept the restaurant. Then using Google Maps Javascript API and Google Maps Direction API, the application will output directions to get to the user's choice from the location they inputed. The user can also choose a previous restaurant if they preferred a previous choice instead of their current.